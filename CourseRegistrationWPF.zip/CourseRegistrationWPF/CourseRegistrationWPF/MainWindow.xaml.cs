﻿using System.Windows;

namespace CourseRegistrationWPF
{
    public partial class MainWindow : Window
    {
        private const double AdvanceAmount = 10; 

        public MainWindow()
        {
            InitializeComponent();
        }
        private void Course_Checked(object sender, RoutedEventArgs e)
        {
            CalculateTotalFee();
        }
        private void Skill_Checked(object sender, RoutedEventArgs e)
        {
            CalculateTotalFee();
        }

        private void CalculateTotalFee()
        {
            double total = 0;
            if (chkCSharp.IsChecked == true) total += 200;
            if (chkJava.IsChecked == true) total += 180;
            if (chkJS.IsChecked == true) total += 150;
            if (chkROR.IsChecked == true) total += 170;
            double discount = 0;
            if (rbIntermediate.IsChecked == true) discount = 0.10; // 10% discount
            else if (rbAdvanced.IsChecked == true) discount = 0.15; // 15% discount
            total = total - (total * discount);
            txtTotal.Text = "$" + total.ToString("F2");      // total fee
            txtAdvance.Text = "$" + AdvanceAmount.ToString("F2"); // advance
        }
    }
}
